const slideMods   = document.querySelectorAll('.module-slider');

let slideIndex = 1;

let wWidth;

function showSlides(w,n) {
    const slides      = w.querySelectorAll(".slide-item");
    const indicateEls = w.querySelectorAll('.slide-indicate-item');
    slides.forEach((img) => {
        img.style.display = "none";
    });
    if (indicateEls.length > 0) {
        indicateEls.forEach((item) => {
            item.classList.remove('active');
        });
        indicateEls[n - 1].classList.add('active');
    }
    slides[n-1].style.display = "block";
}

function autoRotateImg(w) {
    const hoverDetect     = w.querySelector(".row");
    //detect if mouse is over
    if (hoverDetect.parentNode.matches(":hover")) {
        return false;
    }
    const items = w.querySelectorAll(".slide-indicate-item");
    const total = items.length;
    //get position and advance
    const currentSlide     = w.querySelector(".slide-indicate .active");
    const CurrentN = parseInt(currentSlide.getAttribute('data-slide'));
    if (typeof CurrentN === 'number') {
        let n = CurrentN +1;
        if (n > total) {
            n = 1;
        }
        autoRotateText(w,n);
        showSlides(w,n);
    }
    return false;
}

function autoRotateText(w,n) {

    const texts      = w.querySelectorAll(".slide-text");
    let textsCount = texts.length;
    let text = w.querySelector('[data-text="' + n + '"]');
    texts.forEach((text) => {
        text.style.transform = 'translateX(-' + (((textsCount * 100)) - (n * 100)) + '%)';
        text.classList.remove('active');
    });
    text.classList.add('active');
}

//init on load
window.addEventListener("load",function(event) {
    //init each slider
    if (slideMods.length > 0) {
        slideMods.forEach((slider) => {
            const wrap = slider.querySelector(".slide-text-wrap");
            wrap.style.opacity = 1;
            const texts = slider.querySelectorAll(".slide-text");
            let textsCount = texts.length;
            //introduce first slides
            texts.forEach((text) => {
                text.style.transform = 'translateX(-' + ((textsCount * 100) - 100) + '%)';
            });
            //hide loader
            slider.classList.add('loaded');
            //load image slides
            showSlides(slider, slideIndex);
        });
    }
});


slideMods.forEach((slider) => {
    const indicateEls = slider.querySelectorAll('.slide-indicate-item');
    const autoSlide = parseInt(slider.getAttribute('data-auto'));
    //detect if mobile and donot autorotate
    wWidth = window.innerWidth;
    //set interval timeout to progress
    if (indicateEls.length > 0 && typeof autoSlide === 'number' && autoSlide > 2000 && wWidth > 767){
        setInterval(function(){
            autoRotateImg(slider);
        }, autoSlide);
    }
    //add click listeners
    indicateEls.forEach((item) => {
        const texts      = slider.querySelectorAll(".slide-text");
        item.addEventListener('click', (e) => {
            let goTo = e.target.getAttribute('data-slide');
            autoRotateText(slider,goTo);
            showSlides(slider, goTo);
            return false;
        });
    });
});
