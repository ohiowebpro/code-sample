<!-- tabs block -->
<?php
$className = '';
if( !empty($block['className']) ) {
    $className = ' ' . $block['className'];
}

$tabs = get_field('tabs');

?>

<div class="mta-tabs <?php echo $className;?>" id="<?php echo $block['id'];?>">
    <ul class="nav nav-tabs" id="mta-tabs-1" role="tablist">

        <?php
        
        $active = ' show active';
        $cnt = 1;
        $tab_content = '';
        foreach ($tabs as $tab) {

        ?>

            <li class="nav-item" role="presentation">
                <button class="nav-link<?php echo $active;?>" id="mta-tabs-<?php echo $block['id'];?>-<?php echo $cnt;?>" data-bs-toggle="tab" data-bs-target="#mta-tabs-<?php echo $block['id'];?>-content-<?php echo $cnt;?>" type="button" role="tab" aria-controls="mta-tabs-<?php echo $block['id'];?>-<?php echo $cnt;?>" aria-selected="true"><?php echo $tab['tab_title'];?></button>
            </li>

        <?php
        
            $tab_content .= '<div class="tab-pane fade'.$active.'" id="mta-tabs-'.$block['id'].'-content-'.$cnt.'" role="tabpanel" aria-labelledby="mta-tabs-'.$block['id'].'-'.$cnt.'" tabindex="0">'.$tab['tab_content'].'</div>';
            $cnt ++;
            $active = '';
        }

        ?>

    </ul>
    <div class="tab-content" id="mta-tabs-<?php echo $block['id'];?>-content">
        <?php echo $tab_content;?>
    </div>
</div>

