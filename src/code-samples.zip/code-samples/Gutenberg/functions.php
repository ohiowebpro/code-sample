<?php
add_action('after_setup_theme', function () {
    register_block_type( dirname(__FILE__) . '/blocks/tabs/block.json' );
}, 20);
