<article @php(post_class('directory-single-wrap'))>
    <div class="row">
        <div class="col-lg-7 col-xl-8">
            <div class="directory-details p-5 module">
            
                {!! edit_swg_module('Business', get_the_id(), 'top right') !!}
                @include('sections.icons.tribal4')

                <h1 class="mt-2 mb-0">{!! $title !!}</h1>
                
                @if ($catname)
                
                    <p class="mt-1 mb-4">
                        @foreach ($catname as $thisCat)
                            @if ($thisCat->parent != 0)
                            <a href="{{ get_category_link($thisCat->term_id)  }}" class="mta-badge">{!!  $thisCat->name !!}</a>
                            @endif
                        @endforeach
                    </p>
                    
                @endif

                {!!  get_field('main_content')  !!}

                @if (get_field('website')) <p>@include('sections.icons.arrow')<a href="{{ get_field('website') }}" class="" target="_blank">{{ rtrim(str_ireplace(array('http://','https://'), '',get_field('website')),'/') }}</a></p> @endif
                
                @if(get_field('phone_number')) <p>@include('sections.icons.phone')<a href="tel:{{ get_field('phone_number') }}" class="">{{ get_field('phone_number') }}</a></p> @endif
                
                <p>@include('sections.icons.marker')<a href="https://www.google.com/maps/search/?api=1&query={{ urlencode(get_field('street').' '.get_field('city').' '.get_field('state'). ' '.get_field('zip')) }}" target="_blank">{{ get_field('street') }}, {{ get_field('city') }}, {{ get_field('state') }} {{ get_field('zip') }}</a></p>
                
                @if (!get_field('hide_email'))
                    <p>@include('sections.icons.email')<a href="mailto:{{ get_field('email') }}" class="">{{ get_field('email') }}</a></p>
                @endif
                
            </div>

        </div>
        <div class="col-lg-5 col-xl-4 mta-slider mta-slider-wide" >

            @if ($photos != null)

            <div id="carousel-{{ $post_slug }}" class="carousel slide" data-bs-ride="carousel" data-bs-interval="7000">
                <div class="carousel-inner">

                        @foreach($photos as $photo)

                            <div class="carousel-item @if($loop->first) active @endif">
                                <img src="{{ $photo['photo']['sizes']['mta-circle-slider'] }}" class="d-block w-100" alt="{{ $photo['photo']['alt'] }}">
                            </div>

                        @endforeach

                    @if ($featured)

                        <div class="carousel-item @if(!$photos) active @endif">
                            <img src="{{ $featured['sizes']['mta-circle-slider'] }}" class="d-block w-100" alt="{{ $featured['alt'] }}">
                        </div>

                    @endif
                </div>

                @if( (!$featured && count($photos) == 1) ||(!$photos && $featured))

                    <!-- Only one photo - controls not needed -->

                @else

                <button class="carousel-control-prev" type="button" data-bs-target="#carousel-{{ $post_slug }}" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#carousel-{{ $post_slug }}" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>

                @endif

            </div>
            @elseif($featured)

                <img src="{{ $featured['sizes']['mta-circle-slider'] }}" class="d-block w-100" alt="{{ $featured['alt'] }}">

            @endif
        </div>
    </div>

    @php(comments_template())

</article>
